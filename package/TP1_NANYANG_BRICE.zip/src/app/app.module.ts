import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AcceuilComponent } from './acceuil/acceuil.component';
import { BannerComponent } from './banner/banner.component';
import { AproposComponent } from './apropos/apropos.component';
import { CinemaComponent } from './cinema/cinema.component';
import { DetailsMovieComponent } from './details-movie/details-movie.component';
import { FeaturesComponent } from './features/features.component';
import { ImagesDuFilmComponent } from './images-du-film/images-du-film.component';
import { ListeDesAuteursComponent } from './liste-des-auteurs/liste-des-auteurs.component';
import { ListeDesCollectionsComponent } from './liste-des-collections/liste-des-collections.component';
import { ListeDesEvenementsComponent } from './liste-des-evenements/liste-des-evenements.component';
import { ListeDesPersonnagesComponent } from './liste-des-personnages/liste-des-personnages.component';
import { ListeDesStoriesComponent } from './liste-des-stories/liste-des-stories.component';
import { MovieComponent } from './movie/movie.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    AcceuilComponent,
    BannerComponent,
    AproposComponent,
    CinemaComponent,
    DetailsMovieComponent,
    FeaturesComponent,
    ImagesDuFilmComponent,
    ListeDesAuteursComponent,
    ListeDesCollectionsComponent,
    ListeDesEvenementsComponent,
    ListeDesPersonnagesComponent,
    ListeDesStoriesComponent,
    MovieComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
