import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MovieComponent } from './movie/movie.component';
import { AcceuilComponent } from './acceuil/acceuil.component';
import { CinemaComponent } from './cinema/cinema.component';
import { AproposComponent } from './apropos/apropos.component';
import { DetailsMovieComponent } from './details-movie/details-movie.component';

const routes: Routes = [
  {
    path: '', component: AcceuilComponent
  },
  {
    path: 'acceuil', component: AcceuilComponent
  },
  {
    path: 'acceuil', component: AcceuilComponent
  },
  {
    path: 'cinema', component: CinemaComponent
  },
  { path: 'Apropos', component: AproposComponent },
  { path: 'details-movies/:id', component: DetailsMovieComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
