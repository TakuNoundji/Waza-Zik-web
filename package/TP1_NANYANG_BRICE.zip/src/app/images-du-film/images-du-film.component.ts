import { Component } from '@angular/core';
import { Comic } from '../../Ressource/model';
import { Input } from '@angular/core';
import { movie } from '../details-movie/details-movie.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-images-du-film',
  templateUrl: './images-du-film.component.html',
  styleUrls: ['./images-du-film.component.scss']
})
export class ImagesDuFilmComponent {

  @Input() inter: Comic[] = movie;
  constructor(private router: ActivatedRoute) {
  }
}
