import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { SimpleComic, Comic } from '../../Ressource/model';
import { COMICS, COMIC } from '../../Ressource/data';
import { ActivatedRoute } from '@angular/router';
export const movie: Comic[] = []
@Component({
  selector: 'app-details-movie',
  templateUrl: './details-movie.component.html',
  styleUrls: ['./details-movie.component.scss']
})
export class DetailsMovieComponent {
  id: string | null = '';
  @Input() comic: SimpleComic = COMIC;
  @Input() comics: Comic[] = COMICS;
  inter: Comic | any;

  constructor(private router: ActivatedRoute) { }

  ngOnInit() {
    this.id = this.router.snapshot.paramMap.get("id");
    for (let index = 0; index < this.comics.length; index++) {
      if (this.comics[index].description == null) {
        this.comics[index].description = this.comic.description;
      }
      if (this.comics[index].id.toString() === this.id) {
        this.inter = this.comics[index];
        movie.push(this.inter);
      }
    }
  }
}
